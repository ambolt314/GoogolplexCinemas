﻿

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;



DROP TABLE IF EXISTS `actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actor` (
  `actor_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `actor_fname` text NOT NULL,
  `actor_mname` text,
  `actor_lname` text NOT NULL,
  PRIMARY KEY (`actor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `actor` WRITE;
/*!40000 ALTER TABLE `actor` DISABLE KEYS */;
INSERT INTO `actor` VALUES (1,'Michael','','Keaton'),(2,'Alec','','Baldwin'),(3,'Geena','','Davis'),(4,'Winona','','Ryder'),(5,'Catherine','','O\'Hara'),(6,'Steve','','Carrell'),(7,'Jason','','Segel'),(8,'Russell','','Brand'),(9,'Miranda','','Cosgrove'),(10,'Dana','','Gaier'),(11,'Fionn','','Whitehead'),(12,'Tom','','Glynn-Carney'),(13,'Jack','','Lowdens'),(14,'Harry','','Styles'),(15,'Aneurin','','Barnard'),(16,'Miles','','Teller'),(17,'Michael','B','Jordan'),(18,'Kate','','Mara'),(19,'Jamie','','Bell'),(20,'Toby','','Kebbell'),(21,'Mark','','Hamill'),(22,'Carrie','','Fisher'),(23,'Harrison','','Ford'),(24,'Peter','','Cushing'),(25,'Alec','','Guinness'),(26,'Matt','','Damon'),(27,'Robin','','Williams'),(28,'Ben','','Affleck'),(29,'Stellan','','Skarsgård'),(30,'Minnie','','Driver'),(31,'Bryan','','Cranston'),(32,'Alan','','Arkin'),(33,'John','','Goodman'),(34,'Tate','','Donovan'),(35,'Tom','','Cruise'),(36,'Jack','','Nicholson'),(37,'Demi','','Moore'),(38,'Kevin','','Bacon'),(39,'Kiefer','','Sutherland'),(40,'Daniel','','Radcliffe'),(41,'Rupert','','Grint'),(42,'Emma','','Watson'),(43,'Tom','','Felton'),(44,'John','','Cleese'),(45,'Kenneth','','Branagh'),(46,'Robbie','','Coltrane'),(47,'Michael','','Gambon'),(48,'Kurt','','Russell'),(49,'Kim','','Cattrall'),(50,'Dennis','','Dun'),(51,'James','','Hong'),(52,'Victor','','Wong'),(53,'Judd','','Nelson'),(54,'Molly','','Ringwald'),(55,'Emilio','','Estevez'),(56,'Anthony','Michael','Hall'),(57,'Ally','','Sheedy'),(58,'James','','Van Der Beek'),(59,'Anna','','Paquin'),(60,'Cloris','','Leachman'),(61,'Jim','','Cummings'),(62,'Matthew','','McConaughey'),(63,'Anne','','Hathaway'),(64,'Jessica','','Chastain'),(65,'John','','Lithgow'),(66,'Michael','','Caine'),(67,'Lori','','Singer'),(68,'Dianne','','Wiest'),(69,'Chris','','Penn'),(70,'Vincent','','Lindon'),(71,'Firat','','Ayverdi'),(72,'Audrey','','Dana'),(73,'Olivier','','Rabourdin'),(74,'Derya','','Ayverdi'),(75,'Audrey','','Tautou'),(76,'Mathieu','','Kassovitz'),(77,'Rufus','',''),(78,'Serge','','Merlin'),(79,'Lorella','','Cravotta'),(80,'Emily','','Mortimer'),(81,'Christian','','Bale'),(82,'Lauren','','Bacall'),(83,'Billy','','Crystal'),(84,'Jean','','Simmons'),(85,'Nick','','Robinson'),(86,'Josh','','Duhamel'),(87,'Jennifer','','Garner'),(88,'Katherine','','Langford'),(89,'Alexandra','','Shipp'),(90,'John','','Wayne'),(91,'Kenneth','','More'),(92,'Gert','','Fröbe'),(93,'Sean','','Connery'),(94,'Henry','','Fonda'),(95,'Patricia','','Arquette'),(96,'Ellar','','Coltrane'),(97,'Lorelei','','Linklater'),(98,'Ethan','','Hawke'),(99,'Libby','','Villari'),(100,'Kirk','','Douglas'),(101,'Laurence','','Olivier'),(102,'Charles','','Laughton'),(103,'Peter','','Ustinov'),(104,'Gwyneth','','Paltrow'),(105,'Joseph','','Fiennes'),(106,'Geoffrey','','Rush'),(107,'Colin','','Firth'),(108,'Yul','','Brynner'),(109,'Richard','','Benjamin'),(110,'James','','Brolin'),(111,'Norman','','Bartold'),(112,'Alan','','Oppenheimer');
/*!40000 ALTER TABLE `actor` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking` (
  `booking_ref` smallint(6) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `screening_id` smallint(5) unsigned NOT NULL,
  `ticket_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`booking_ref`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (1,1,1,1),(2,3,1,2),(3,3,1,3),(4,2,1,4),(5,2,2,5),(6,3,2,6),(7,4,2,7),(8,2,2,8),(9,5,2,9),(10,1,2,10),(11,5,2,11),(12,3,2,12),(13,3,3,13),(14,3,3,14),(15,2,3,15),(16,5,3,16),(17,1,3,17),(18,5,3,18),(19,1,3,19),(20,1,3,20),(21,1,3,21),(22,1,3,22),(23,4,4,23),(24,1,4,24),(25,4,4,25),(26,3,4,26),(27,5,4,27),(28,1,4,28),(29,5,4,29),(30,5,5,30),(31,3,5,31),(32,4,5,32),(33,1,5,33),(34,5,5,34),(35,4,5,35),(36,1,5,36),(37,3,6,37),(38,1,8,38),(39,5,8,39),(40,5,11,40),(41,2,13,41),(42,3,13,42),(43,3,13,43),(44,3,13,44),(45,2,14,45),(46,3,17,46),(47,4,18,47),(48,3,19,48),(49,5,22,49),(50,3,22,50);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `booking_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_request` (
  `request_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `film_ref` mediumint(8) unsigned NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `request_date` date DEFAULT NULL,
  `request_time` time DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `film_ref` (`film_ref`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `booking_request_ibfk_1` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`),
  CONSTRAINT `booking_request_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `booking_request` WRITE;
/*!40000 ALTER TABLE `booking_request` DISABLE KEYS */;
INSERT INTO `booking_request` VALUES (1,20,2,'2018-01-02','12:24:06'),(2,2,2,'2018-01-05','19:01:12'),(3,23,1,'2018-01-08','09:54:22'),(4,11,1,'2018-01-08','12:01:31'),(5,16,3,'2018-01-08','12:44:23'),(6,2,1,'2018-01-09','15:27:14'),(7,7,1,'2018-01-10','08:50:25'),(8,13,2,'2018-01-10','18:42:41'),(9,22,1,'2018-01-11','11:15:24'),(10,19,4,'2018-01-14','19:50:56'),(11,2,1,'2018-01-15','14:43:36'),(12,6,4,'2018-01-18','10:20:06'),(13,2,2,'2018-01-19','09:50:38'),(14,23,4,'2018-01-19','10:31:12'),(15,9,3,'2018-01-20','11:27:42'),(16,23,3,'2018-01-24','13:18:33'),(17,4,1,'2018-01-24','14:47:34'),(18,7,2,'2018-01-25','20:47:40'),(19,23,1,'2018-01-26','11:29:24'),(20,20,3,'2018-01-26','13:18:25'),(21,13,1,'2018-01-26','15:39:12'),(22,1,4,'2018-01-27','20:48:08'),(23,24,2,'2018-01-29','13:17:07'),(24,25,5,'2018-01-29','21:30:11'),(25,5,2,'2018-01-30','10:03:45'),(26,4,1,'2018-01-30','17:08:27'),(27,18,1,'2018-02-03','09:30:13'),(28,21,2,'2018-02-06','21:52:29'),(29,15,4,'2018-02-07','15:35:28'),(30,1,3,'2018-02-08','10:47:55'),(31,22,5,'2018-02-11','14:50:15'),(32,12,1,'2018-02-11','15:04:13'),(33,20,2,'2018-02-11','18:51:13'),(34,13,3,'2018-02-13','09:53:38'),(35,21,5,'2018-02-14','12:05:04'),(36,16,4,'2018-02-15','18:35:39'),(37,16,5,'2018-02-15','19:09:35'),(38,24,4,'2018-02-16','09:31:39'),(39,16,5,'2018-02-16','11:58:51'),(40,7,1,'2018-02-16','14:47:35'),(41,1,3,'2018-02-17','08:51:13'),(42,18,5,'2018-02-17','17:24:58'),(43,11,2,'2018-02-19','12:50:29'),(44,18,2,'2018-02-20','09:13:38'),(45,15,4,'2018-02-21','08:29:17'),(46,4,4,'2018-02-23','20:21:17'),(47,25,5,'2018-02-25','20:40:45'),(48,10,5,'2018-02-26','08:42:01'),(49,18,3,'2018-02-26','21:18:05'),(50,21,1,'2018-02-28','13:45:59'),(51,21,3,'2018-02-28','17:38:08'),(52,8,3,'2018-02-28','19:23:37'),(53,16,4,'2018-03-01','10:27:55'),(54,13,4,'2018-03-01','11:06:27'),(55,3,1,'2018-03-02','11:55:10'),(56,10,3,'2018-03-03','19:28:48'),(57,5,5,'2018-03-10','09:11:29'),(58,10,3,'2018-03-11','13:49:02'),(59,22,4,'2018-03-11','17:07:40'),(60,11,1,'2018-03-12','19:14:18'),(61,23,3,'2018-03-14','15:32:18'),(62,11,4,'2018-03-14','21:31:27'),(63,13,3,'2018-03-17','08:57:44'),(64,24,1,'2018-03-19','14:31:04'),(65,8,3,'2018-03-19','20:47:00'),(66,23,1,'2018-03-20','09:54:58'),(67,4,4,'2018-03-20','10:31:18'),(68,2,4,'2018-03-23','12:50:10'),(69,18,3,'2018-03-24','09:04:34'),(70,9,4,'2018-03-24','21:35:37'),(71,4,2,'2018-03-25','10:35:21'),(72,20,2,'2018-03-25','12:40:28'),(73,12,4,'2018-03-25','19:46:31'),(74,1,1,'2018-03-29','17:35:53'),(75,14,5,'2018-04-02','13:03:50'),(76,6,3,'2018-04-03','20:43:51'),(77,1,1,'2018-04-04','11:40:15'),(78,19,1,'2018-04-04','11:47:35'),(79,9,5,'2018-04-05','13:28:05'),(80,10,5,'2018-04-06','09:06:43'),(81,14,2,'2018-04-06','12:58:04'),(82,4,3,'2018-04-08','09:21:06'),(83,10,2,'2018-04-09','11:47:24'),(84,2,1,'2018-04-10','14:53:09'),(85,8,3,'2018-04-11','11:31:21'),(86,4,1,'2018-04-12','20:32:13'),(87,24,5,'2018-04-13','20:39:08'),(88,25,4,'2018-04-14','12:13:13'),(89,2,5,'2018-04-16','08:03:20'),(90,4,5,'2018-04-16','08:24:10'),(91,19,3,'2018-04-16','11:59:39'),(92,23,2,'2018-04-16','13:12:19'),(93,2,1,'2018-04-17','13:18:18'),(94,3,2,'2018-04-17','17:15:42'),(95,17,4,'2018-04-18','14:45:46'),(96,11,5,'2018-04-20','10:42:13'),(97,15,1,'2018-04-21','09:35:43'),(98,1,5,'2018-04-21','15:06:35'),(99,15,5,'2018-04-22','21:43:48'),(100,19,4,'2018-04-23','10:34:50');
/*!40000 ALTER TABLE `booking_request` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `cast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cast` (
  `film_ref` mediumint(8) unsigned NOT NULL,
  `actor_id` smallint(6) NOT NULL,
  PRIMARY KEY (`film_ref`,`actor_id`),
  KEY `actor_id` (`actor_id`),
  CONSTRAINT `cast_ibfk_1` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`),
  CONSTRAINT `cast_ibfk_2` FOREIGN KEY (`actor_id`) REFERENCES `actor` (`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `cast` WRITE;
/*!40000 ALTER TABLE `cast` DISABLE KEYS */;
INSERT INTO `cast` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(2,6),(2,7),(2,8),(2,9),(2,10),(3,11),(3,12),(3,13),(3,14),(3,15),(4,16),(4,17),(4,18),(4,19),(4,20),(5,21),(14,21),(5,22),(5,23),(5,24),(5,25),(6,26),(6,27),(6,28),(7,28),(24,28),(6,29),(6,30),(7,31),(7,32),(7,33),(7,34),(8,35),(8,36),(8,37),(8,38),(19,38),(8,39),(9,40),(10,40),(11,40),(9,41),(10,41),(11,41),(9,42),(10,42),(11,42),(9,43),(10,43),(11,43),(9,44),(10,45),(9,46),(10,46),(11,46),(11,47),(12,48),(12,49),(12,50),(12,51),(12,52),(13,53),(13,54),(13,55),(13,56),(13,57),(14,58),(14,59),(14,60),(14,61),(18,62),(18,63),(18,64),(18,65),(19,65),(18,66),(19,67),(19,68),(19,69),(15,70),(15,71),(15,72),(15,73),(15,74),(16,75),(16,76),(16,77),(16,78),(16,79),(17,80),(17,81),(17,82),(17,83),(17,84),(23,84),(21,85),(21,86),(21,87),(21,88),(21,89),(20,90),(20,91),(20,92),(20,93),(20,94),(22,95),(22,96),(22,97),(22,98),(22,99),(23,100),(23,101),(23,102),(23,103),(24,104),(24,105),(24,106),(24,107),(25,108),(25,109),(25,110),(25,111),(25,112);
/*!40000 ALTER TABLE `cast` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `cinema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cinema` (
  `cinema_postcode` varchar(20) NOT NULL,
  `cinema_city` text,
  PRIMARY KEY (`cinema_postcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `cinema` WRITE;
/*!40000 ALTER TABLE `cinema` DISABLE KEYS */;
INSERT INTO `cinema` VALUES ('CO1 5RJ',' \"Colchester\"'),('IP1 1AG',' \"Ipswich Central\"'),('IP9 9DL',' \"Stour Valley'),('NR1 7UP',' \"Norwich Central\"'),('NR2 3ER',' \"Norwich North\"');
/*!40000 ALTER TABLE `cinema` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `customer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_fname` text,
  `customer_lname` text,
  `customer_email` text,
  `customer_hasloyaltycard` tinyint(1) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Alex','Peterson','ap@fakemail.com',0),(2,'Joan','Robbins','joan.2.robbins@fakemail.com',0),(3,'Samantha','Major','major.sam@fakemail.com',1),(4,'Lee','Gray','lee.gees@fakemail.com',1),(5,'Billy','Smith','bs@fakemail.com',0),(6,'Pat','Barnes','pbnoj@fakemail.com',1),(7,'Dom','Jameston','dom.jameston@fakemail.com',1),(8,'Tom','Jones','notthattomjones921@fakemail.com',1),(9,'Clément','Chevalier','ciderlegend123@fakemail.com',0);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `director` (
  `director_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `director_fname` text NOT NULL,
  `director_lname` text NOT NULL,
  PRIMARY KEY (`director_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `director` WRITE;
/*!40000 ALTER TABLE `director` DISABLE KEYS */;
INSERT INTO `director` VALUES (1,'Chris','Renaud'),(2,'Christopher','Nolan'),(3,'George','Lucas'),(4,'Josh','Trank'),(5,'Pierre','Coffin'),(6,'Tim','Burton'),(7,'Andrew','Marton'),(8,'Ben','Affleck'),(9,'Bernhard','Wicki'),(10,'Chris','Columbus'),(11,'Greg','Berlanti'),(12,'Gus','Van Sant'),(13,'Hayao','Miyazaki'),(14,'Herbert','Ross'),(15,'Jean-Pierre','Jeunet'),(16,'John','Carpenter'),(17,'John','Hughes'),(18,'John','Madden'),(19,'Ken','Annakin'),(20,'Michael','Crichton'),(21,'Philippe','Lioret'),(22,'Richard','Linklater'),(23,'Rob','Reiner'),(24,'Stanley','Kubrick');
/*!40000 ALTER TABLE `director` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `film`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `film` (
  `film_ref` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `film_title` text,
  `film_poster` blob,
  `film_runtime` int(11) DEFAULT NULL,
  `film_certificate` enum('U','PG','12A','15','18') DEFAULT NULL,
  `film_language` text,
  `rating` enum('0.5','1.0','1.5','2.0','2.5','3.0','3.5','4.0','4.5','5.0') DEFAULT NULL,
  `film_releaseyear` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`film_ref`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `film` WRITE;
/*!40000 ALTER TABLE `film` DISABLE KEYS */;
INSERT INTO `film` VALUES (1,'Beetlejuice',' null',92,'15','English','3.5','1988'),(2,'Despicable Me',' null',96,'U','English','1.5','2010'),(3,'Dunkirk',' null',106,'12A','English','2.5','2017'),(4,'Fantastic Four',' null',99,'12A','English','0.5','2015'),(5,'Star Wars',' null',121,'U','English','2.5','1977'),(6,'Good Will Hunting',' null',126,'15','English','3.5','1997'),(7,'Argo',' null',120,'15','English','1.5','2012'),(8,'A Few Good Men',' null',138,'PG','English','2.5','1992'),(9,'Harry Potter and the Philosopher\'s Stone',' null',152,'PG','English','2.0','2001'),(10,'Harry Potter and the Chamber of Secrets',' null',161,'PG','English','3.5','2003'),(11,'Harry Potter and the Prisoner of Azkaban',' null',142,'PG','English','3.5','2004'),(12,'Big Trouble in Little China',' null',99,'15','English','1.0','1986'),(13,'The Breakfast Club',' null',97,'15','English','4.5','1984'),(14,'Castle in the Sky',' null',126,'PG','Japanese','3.5','1986'),(15,'Welcome',' null',110,'15','French','2.5','2009'),(16,'Amelie',' null',123,'15','French','2.5','2001'),(17,'Howl\'s Moving Castle',' null',119,'U','Japanese','3.5','2004'),(18,'Interstellar',' null',169,'12A','English','1.5','2014'),(19,'Footloose',' null',110,'12A','English','2.5','1984'),(20,'The Longest Day',' null',178,'PG','English','4.5','1962'),(21,'Love, Simon',' null',110,'12A','English','2.5','2018'),(22,'Boyhood',' null',165,'15','English','1.5','2014'),(23,'Spartacus',' null',184,'PG','English','3.5','1960'),(24,'Shakespeare in Love',' null',123,'15','English','1.0','1998'),(25,'Westworld',' null',88,'15','English','2.0','1973');
/*!40000 ALTER TABLE `film` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `film_director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `film_director` (
  `film_ref` mediumint(8) unsigned NOT NULL,
  `director_id` smallint(6) NOT NULL,
  PRIMARY KEY (`film_ref`,`director_id`),
  KEY `director_id` (`director_id`),
  CONSTRAINT `film_director_ibfk_1` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`),
  CONSTRAINT `film_director_ibfk_2` FOREIGN KEY (`director_id`) REFERENCES `director` (`director_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `film_director` WRITE;
/*!40000 ALTER TABLE `film_director` DISABLE KEYS */;
INSERT INTO `film_director` VALUES (2,1),(3,2),(18,2),(5,3),(4,4),(2,5),(1,6),(20,7),(7,8),(20,9),(9,10),(10,10),(11,11),(21,11),(6,12),(14,13),(17,13),(19,14),(16,15),(12,16),(13,17),(24,18),(20,19),(25,20),(15,21),(22,22),(8,23),(23,24);
/*!40000 ALTER TABLE `film_director` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `film_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `film_genre` (
  `film_ref` mediumint(8) unsigned NOT NULL,
  `genre` varchar(25) NOT NULL,
  PRIMARY KEY (`film_ref`,`genre`),
  KEY `genre` (`genre`),
  CONSTRAINT `film_genre_ibfk_1` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`),
  CONSTRAINT `film_genre_ibfk_2` FOREIGN KEY (`genre`) REFERENCES `genre` (`genre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `film_genre` WRITE;
/*!40000 ALTER TABLE `film_genre` DISABLE KEYS */;
INSERT INTO `film_genre` VALUES (5,'Action'),(5,'Adventure'),(14,'Adventure'),(18,'Adventure'),(2,'Animated'),(14,'Animated'),(17,'Animated'),(1,'Comedy'),(2,'Comedy'),(12,'Comedy'),(13,'Comedy'),(16,'Comedy'),(21,'Comedy'),(24,'Comedy'),(13,'Coming-of-age'),(22,'Coming-of-age'),(3,'Drama'),(6,'Drama'),(7,'Drama'),(8,'Drama'),(13,'Drama'),(15,'Drama'),(18,'Drama'),(19,'Drama'),(21,'Drama'),(22,'Drama'),(23,'Drama'),(24,'Drama'),(1,'Fantasy'),(5,'Fantasy'),(9,'Fantasy'),(10,'Fantasy'),(11,'Fantasy'),(12,'Fantasy'),(17,'Fantasy'),(3,'Historical'),(7,'Historical'),(23,'Historical'),(1,'Horror'),(8,'Legal'),(12,'Martial Arts'),(19,'Musical'),(24,'Period'),(5,'Sci-Fi'),(18,'Sci-Fi'),(25,'Sci-Fi'),(4,'Superhero'),(25,'Thriller'),(3,'War'),(20,'War'),(25,'Western');
/*!40000 ALTER TABLE `film_genre` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `film_music`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `film_music` (
  `film_ref` mediumint(8) unsigned NOT NULL,
  `artist_id` smallint(6) NOT NULL,
  PRIMARY KEY (`film_ref`,`artist_id`),
  KEY `artist_id` (`artist_id`),
  CONSTRAINT `film_music_ibfk_1` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `film_music` WRITE;
/*!40000 ALTER TABLE `film_music` DISABLE KEYS */;
INSERT INTO `film_music` VALUES (22,0),(1,1),(6,1),(2,2),(2,3),(3,4),(18,4),(4,5),(4,6),(5,7),(9,7),(10,7),(11,7),(7,8),(8,9),(12,10),(12,11),(13,12),(13,13),(14,14),(17,14),(15,15),(15,16),(15,17),(16,18),(19,19),(19,20),(19,21),(19,22),(20,23),(20,24),(21,25),(23,26),(24,27),(25,28);
/*!40000 ALTER TABLE `film_music` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `film_studio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `film_studio` (
  `film_ref` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `studio_name` varchar(100) NOT NULL,
  PRIMARY KEY (`film_ref`,`studio_name`),
  KEY `studio_name` (`studio_name`),
  CONSTRAINT `film_studio_ibfk_1` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`),
  CONSTRAINT `film_studio_ibfk_2` FOREIGN KEY (`studio_name`) REFERENCES `studio` (`studio_name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `film_studio` WRITE;
/*!40000 ALTER TABLE `film_studio` DISABLE KEYS */;
INSERT INTO `film_studio` VALUES (9,'1492 Pictures'),(10,'1492 Pictures'),(11,'1492 Pictures'),(4,'20th Century Fox'),(5,'20th Century Fox'),(12,'20th Century Fox'),(20,'20th Century Fox'),(21,'20th Century Fox'),(13,'A&M Films'),(6,'Be Gentlemen'),(23,'Bryna Productions'),(16,'Canal+'),(8,'Castle Rock Entertainment'),(13,'Channel Productions'),(22,'Cinectic Media'),(8,'Columbia Pictures'),(20,'Darryl F. Zanuck Productions, Inc.'),(22,'Detour Filmproduction'),(7,'GK Films'),(9,'Heyday Films'),(10,'Heyday Films'),(11,'Heyday Films'),(22,'IFC Productions'),(2,'Illumination Entertainment'),(19,'IndieProd Company Productions'),(4,'Kinberg Genre'),(4,'Konstantin Film'),(5,'Lucasfilm'),(18,'Lynda Obst Productions'),(15,'Mars Distribution'),(4,'Marv Films'),(4,'Marvel Entertainment'),(25,'Metro-Goldwyn-Mayer'),(6,'Miramax Films'),(24,'Miramax Films'),(15,'Nord-Ouest Productions'),(18,'Paramount Pictures'),(19,'Paramount Pictures'),(4,'Robert Kulzer Productions'),(7,'Smokehouse Pictures'),(15,'Studio 37'),(14,'Studio Ghibli'),(17,'Studio Ghibli'),(3,'Syncopy Inc.'),(18,'Syncopy Inc.'),(24,'The Bedford Falls Company'),(1,'The Geffen Film Company'),(14,'Toei Company'),(17,'Toho'),(4,'TSG Entertainment'),(16,'UGC'),(16,'UGC Fox Distribution'),(23,'Universal International'),(2,'Universal Pictures'),(13,'Universal Pictures'),(22,'Universal Pictures'),(24,'Universal Pictures'),(1,'Warner Bros.'),(3,'Warner Bros.'),(7,'Warner Bros.'),(9,'Warner Bros.'),(10,'Warner Bros.'),(11,'Warner Bros.'),(18,'Warner Bros.');
/*!40000 ALTER TABLE `film_studio` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genre` (
  `genre` varchar(25) NOT NULL,
  PRIMARY KEY (`genre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `genre` WRITE;
/*!40000 ALTER TABLE `genre` DISABLE KEYS */;
INSERT INTO `genre` VALUES ('Action'),('Adventure'),('Animated'),('Comedy'),('Coming-of-age'),('Drama'),('Fantasy'),('Historical'),('Horror'),('Legal'),('Martial Arts'),('Musical'),('Period'),('Romance'),('Sci-Fi'),('Superhero'),('Thriller'),('War'),('Western');
/*!40000 ALTER TABLE `genre` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `music`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `music` (
  `artist_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `artist_fname` text,
  `artist_lname` text,
  PRIMARY KEY (`artist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `music` WRITE;
/*!40000 ALTER TABLE `music` DISABLE KEYS */;
INSERT INTO `music` VALUES (1,'Danny','Elfman'),(2,'Heitor','Pereira'),(3,'Pharrell','Williams'),(4,'Hans','Zimmer'),(5,'Marco','Beltrami'),(6,'Philip','Glass'),(7,'John','Williams'),(8,'Alexandre','Desplat'),(9,'Marc','Shaiman'),(10,'John','Carpenter'),(11,'Alan','Howarth'),(12,'Keith','Forsey'),(13,'Gary','Chang'),(14,'Joe','Hisaishi'),(15,'Nicola','Piovani'),(16,'Wojciech','Kilar'),(17,'Armand','Amar'),(18,'Yann','Tiersen'),(19,'Tom','Snow'),(20,'Jim','Steinman'),(21,'Kenny','Loggins'),(22,'Dean','Pitchford'),(23,'Maurice','Jarre'),(24,'Paul','Anka'),(25,'Rob','Simonsen'),(26,'Alex','North'),(27,'Stephen','Warbeck'),(28,'Fred','Karlin');
/*!40000 ALTER TABLE `music` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cinema_postcode` varchar(20) NOT NULL,
  `film_ref` mediumint(8) unsigned NOT NULL,
  `item_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `cinema_postcode` (`cinema_postcode`),
  KEY `film_ref` (`film_ref`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`cinema_postcode`) REFERENCES `cinema` (`cinema_postcode`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'IP1 1AG',1,1),(2,'NR2 3ER',2,2),(3,'NR1 7UP',1,1),(4,'NR1 7UP',2,1),(5,'IP9 9DL',1,2),(6,'IP9 9DL',2,1),(7,'IP9 9DL',3,1),(8,'NR1 7UP',3,1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `cinema_postcode` varchar(20) NOT NULL,
  `room_number` varchar(2) NOT NULL,
  `room_capacity` mediumint(9) NOT NULL,
  PRIMARY KEY (`cinema_postcode`,`room_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES ('CO1 5RJ','1',100),('IP1 1AG','1',50),('IP9 9DL','1',50),('IP9 9DL','5',50),('NR1 7UP','1',150),('NR1 7UP','2',100),('NR1 7UP','3',200),('NR2 3ER','1',150);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `screening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `screening` (
  `screening_id` smallint(5) unsigned NOT NULL,
  `ticket_id` mediumint(8) unsigned NOT NULL,
  `booking_ref` smallint(5) unsigned NOT NULL,
  `cinema_postcode` varchar(16) NOT NULL,
  `room_number` varchar(2) DEFAULT NULL,
  `screening_time` time NOT NULL,
  `screening_date` date NOT NULL,
  `film_ref` mediumint(8) unsigned NOT NULL,
  KEY `ticket_id` (`ticket_id`),
  KEY `cinema_postcode` (`cinema_postcode`),
  KEY `booking_ref` (`booking_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `screening` WRITE;
/*!40000 ALTER TABLE `screening` DISABLE KEYS */;
INSERT INTO `screening` VALUES (1,1,1,'IP1 1AG','1','15:30:00','2018-01-01',3),(1,2,2,'IP1 1AG','1','15:30:00','2018-01-01',3),(1,3,3,'IP1 1AG','1','15:30:00','2018-01-01',3),(1,4,4,'IP1 1AG','1','15:30:00','2018-01-01',3),(2,5,5,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,6,6,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,7,7,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,8,8,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,9,9,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,10,10,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,11,11,'NR2 3ER','1','18:00:00','2018-01-02',2),(2,12,12,'NR2 3ER','1','18:00:00','2018-01-02',2),(3,13,13,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,14,14,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,15,15,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,16,16,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,17,17,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,18,18,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,19,19,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,20,20,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,21,21,'CO1 5RJ','1','19:45:00','2018-01-02',7),(3,22,22,'CO1 5RJ','1','19:45:00','2018-01-02',7),(4,4,23,'NR1 7UP','1','14:15:00','2018-01-01',4),(5,5,24,'IP9 9DL','1','20:30:00','2018-01-03',6),(6,6,25,'IP1 1AG','1','20:00:00','2018-01-01',3),(7,7,26,'CO1 5RJ','1','18:00:00','2018-01-02',3),(8,8,27,'NR1 7UP','2','19:45:00','2018-01-02',1),(9,9,28,'NR1 7UP','3','17:00:00','2018-01-03',10),(10,10,29,'IP9 9DL','5','20:30:00','2018-01-03',11),(11,11,30,'CO1 5RJ','1','20:00:00','2018-01-01',25),(12,12,31,'IP9 9DL','2','18:00:00','2018-01-02',4),(13,13,32,'IP1 1AG','3','20:30:00','2018-01-03',20),(14,14,33,'IP1 1AG','4','20:00:00','2018-01-01',19),(15,15,34,'IP1 1AG','4','18:00:00','2018-01-02',14),(16,16,35,'IP1 1AG','4','19:45:00','2018-01-02',15),(17,17,36,'IP1 1AG','4','17:00:00','2018-01-03',7),(18,18,37,'IP1 1AG','4','20:30:00','2018-01-03',7),(19,19,38,'IP1 1AG','1','17:00:00','2018-01-01',2),(20,20,39,'CO1 5RJ','1','15:00:00','2018-01-02',1),(21,21,40,'NR1 7UP','2','16:45:00','2018-01-02',5),(22,22,41,'NR1 7UP','3','14:00:00','2018-01-03',15),(23,23,42,'IP9 9DL','5','17:30:00','2018-01-03',12),(1,3,1,'1','IP','00:00:01','2018-01-01',15),(1,3,2,'2','IP','00:00:01','2018-01-01',15),(1,3,3,'3','IP','00:00:01','2018-01-01',15),(1,3,4,'4','IP','00:00:01','2018-01-01',15),(2,2,5,'5','NR','00:00:01','2018-01-02',18),(2,2,6,'6','NR','00:00:01','2018-01-02',18),(2,2,7,'7','NR','00:00:01','2018-01-02',18),(2,2,8,'8','NR','00:00:01','2018-01-02',18),(2,2,9,'9','NR','00:00:01','2018-01-02',18),(2,2,10,'10','NR','00:00:01','2018-01-02',18),(2,2,11,'11','NR','00:00:01','2018-01-02',18),(2,2,12,'12','NR','00:00:01','2018-01-02',18),(3,7,13,'13','CO','00:00:01','2018-01-02',19),(3,7,14,'14','CO','00:00:01','2018-01-02',19),(3,7,15,'15','CO','00:00:01','2018-01-02',19),(3,7,16,'16','CO','00:00:01','2018-01-02',19),(3,7,17,'17','CO','00:00:01','2018-01-02',19),(3,7,18,'18','CO','00:00:01','2018-01-02',19),(3,7,19,'19','CO','00:00:01','2018-01-02',19),(3,7,20,'20','CO','00:00:01','2018-01-02',19),(3,7,21,'21','CO','00:00:01','2018-01-02',19),(3,7,22,'22','CO','00:00:01','2018-01-02',19),(4,4,4,'23','NR','00:00:01','2018-01-01',14),(5,6,5,'24','IP','00:00:01','2018-01-03',20),(6,3,6,'25','IP','00:00:01','2018-01-01',20),(7,3,7,'26','CO','00:00:01','2018-01-02',18),(8,1,8,'27','NR','00:00:02','2018-01-02',19),(9,10,9,'28','NR','00:00:03','2018-01-03',17),(10,11,10,'29','IP','00:00:05','2018-01-03',20),(11,25,11,'30','CO','00:00:01','2018-01-01',20),(12,4,12,'31','IP','00:00:02','2018-01-02',18),(13,20,13,'32','IP','00:00:03','2018-01-03',20),(14,19,14,'33','IP','00:00:04','2018-01-01',20),(15,14,15,'34','IP','00:00:04','2018-01-02',18),(16,15,16,'35','IP','00:00:04','2018-01-02',19),(17,7,17,'36','IP','00:00:04','2018-01-03',17),(18,7,18,'37','IP','00:00:04','2018-01-03',20),(19,2,19,'38','IP','00:00:01','2018-01-01',17),(20,1,20,'39','CO','00:00:01','2018-01-02',15),(21,5,21,'40','NR','00:00:02','2018-01-02',16),(22,15,22,'41','NR','00:00:03','2018-01-03',14),(23,12,23,'42','IP','00:00:05','2018-01-03',17);
/*!40000 ALTER TABLE `screening` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seats` (
  `seat_row` char(1) NOT NULL,
  `seat_number` int(11) NOT NULL,
  `room_number` varchar(2) NOT NULL,
  `cinema_postcode` varchar(20) NOT NULL,
  `ticket_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`seat_row`,`seat_number`),
  KEY `ticket_id` (`ticket_id`),
  KEY `cinema_postcode` (`cinema_postcode`),
  CONSTRAINT `seats_ibfk_1` FOREIGN KEY (`cinema_postcode`) REFERENCES `cinema` (`cinema_postcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `seats` WRITE;
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
INSERT INTO `seats` VALUES ('A',1,'1','IP1 1AG',7),('A',3,'1','IP1 1AG',22),('A',4,'1','CO1 5RJ',12),('A',5,'1','IP1 1AG',1),('A',6,'4','IP1 1AG',18),('A',7,'4','IP1 1AG',19),('B',1,'1','NR2 3ER',2),('B',6,'1','CO1 5RJ',8),('B',7,'4','IP1 1AG',20),('B',8,'4','IP1 1AG',21),('B',13,'1','CO1 5RJ',23),('B',14,'2','NR1 7UP',9),('B',16,'3','NR1 7UP',10),('C',1,'3','NR1 7UP',24),('C',13,'2','NR1 7UP',14),('C',15,'1','CO1 5RJ',3),('C',17,'5','IP9 9DL',11),('D',12,'5','IP9 9DL',25),('D',20,'3','NR1 7UP',15),('E',15,'1','NR1 7UP',4),('E',16,'3','IP1 1AG',16),('F',16,'1','IP9 9DL',5);
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `cinema_postcode` varchar(20) NOT NULL,
  `film_ref` mediumint(8) unsigned NOT NULL,
  `stock_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`cinema_postcode`,`film_ref`),
  KEY `film_ref` (`film_ref`),
  CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`cinema_postcode`) REFERENCES `cinema` (`cinema_postcode`),
  CONSTRAINT `stock_ibfk_2` FOREIGN KEY (`film_ref`) REFERENCES `film` (`film_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES ('CO1 5RJ',1,4),('CO1 5RJ',2,2),('CO1 5RJ',3,1),('CO1 5RJ',4,3),('CO1 5RJ',5,1),('IP1 1AG',1,0),('IP1 1AG',2,3),('IP1 1AG',3,2),('IP1 1AG',4,3),('IP1 1AG',5,1),('IP9 9DL',1,0),('IP9 9DL',2,0),('IP9 9DL',3,0),('IP9 9DL',4,2),('IP9 9DL',5,1),('NR1 7UP',1,0),('NR1 7UP',2,0),('NR1 7UP',3,3),('NR1 7UP',4,2),('NR1 7UP',5,1),('NR2 3ER',1,1),('NR2 3ER',2,0),('NR2 3ER',3,2),('NR2 3ER',4,3),('NR2 3ER',5,1);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `studio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `studio` (
  `studio_name` varchar(100) NOT NULL,
  PRIMARY KEY (`studio_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `studio` WRITE;
/*!40000 ALTER TABLE `studio` DISABLE KEYS */;
INSERT INTO `studio` VALUES ('1492 Pictures'),('20th Century Fox'),('A&M Films'),('Be Gentlemen'),('Bryna Productions'),('Canal+'),('Castle Rock Entertainment'),('Channel Productions'),('Cinectic Media'),('Columbia Pictures'),('Darryl F. Zanuck Productions, Inc.'),('Detour Filmproduction'),('France 3 Cinéma'),('GK Films'),('Heyday Films'),('IFC Productions'),('Illumination Entertainment'),('IndieProd Company Productions'),('Kinberg Genre'),('Konstantin Film'),('Legenday Pictures'),('Lucasfilm'),('Lynda Obst Productions'),('Mars Distribution'),('Marv Films'),('Marvel Entertainment'),('Metro-Goldwyn-Mayer'),('Miramax Films'),('Nord-Ouest Productions'),('Paramount Pictures'),('Robert Kulzer Productions'),('Smokehouse Pictures'),('Studio 37'),('Studio Ghibli'),('Syncopy Inc.'),('The Bedford Falls Company'),('The Geffen Film Company'),('Toei Company'),('Toho'),('TSG Entertainment'),('UGC'),('UGC Fox Distribution'),('Universal International'),('Universal Pictures'),('Warner Bros.');
/*!40000 ALTER TABLE `studio` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `ticket_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_price` decimal(13,2) DEFAULT NULL,
  `ticket_type` enum('Child','Adult','Student','Concession') DEFAULT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (1,5.00,'Adult'),(2,5.00,'Adult'),(3,3.50,'Student'),(4,5.00,'Adult'),(5,5.00,'Adult'),(6,3.50,'Student'),(7,3.50,'Student'),(8,5.00,'Adult'),(9,3.00,'Concession'),(10,5.00,'Adult'),(11,5.00,'Adult'),(12,3.50,'Student'),(13,3.50,'Student'),(14,5.00,'Adult'),(15,3.50,'Student'),(16,3.00,'Concession'),(17,3.00,'Concession'),(18,3.00,'Concession'),(19,3.00,'Concession'),(20,3.00,'Concession'),(21,3.50,'Student'),(22,3.50,'Student'),(23,5.00,'Adult'),(24,3.00,'Child'),(25,5.00,'Adult');
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

